class PageController < ApplicationController
end
